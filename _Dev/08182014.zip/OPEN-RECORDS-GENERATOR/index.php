<?php require_once("GLOBAL/head.php"); ?>



<br />
<br />
<br />
Welcome to the OPEN RECORDS GENERATOR.<br />
<?php echo date("d M Y h:i:s"); ?><br />
<br />
<br />
<a href="browse.php">ENTER DATABASE...</a><br />&nbsp;
</td></tr>




<?php require_once("GLOBAL/foot.php"); ?>