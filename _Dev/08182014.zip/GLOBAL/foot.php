        <div class='navbottomContainer'>
	        <div class='helvetica small black'>
        		<a href='main' class='instructionContainer'>MAIN</a>
        		<a href='visit' class='instructionContainer'>VISIT</a>
        		<a href='exhibitions' class='instructionContainer'>EXHIBITIONS</a>
        		<a href='calendar' class='instructionContainer'>CALENDAR</a>
        		<a href='archive' class='instructionContainer'>ARCHIVE</a>
        		<a href='index_.php' class='instructionContainer'>GO HOME</a>
        	</div>
        </div>

        <!-- CLOSE mainContainer -->

        </div>

        <!-- ADDRESS 

        <div class="dateContainer helvetica small">
                CCA WATTIS INSTITUTE FOR CONTEMPORARY ARTS<br />360 KANSAS STREET / SAN FRANCISCO CA $
        </div>
	-->

	<script>
	        initPunctuation('Punct', 200, true);
	</script>

</body>
</html>
