<?php
require_once("GLOBAL/head.php");
?>

<div class="mainContainer times big black">

<span class="listContainer times show comment">
<canvas id="canvas1" width="46" height="22" class="show">+++</canvas>
Calendar . . .<br/><br/></span> 

<span class="listContainer times show comment"> 

<a href="calendar-detail.php">Thursday, October 22</a> . . . We are showing two films by Joan 
Jonas Next Door.<br /><br />

<a href="">Friday, October 23</a> . . . Ed Ruscha comes to the Wattis 
and will talk about two years in his life, 1960 and 2014.<br /><br />
	
<br /><br />

</span>

<span class="listContainer times show comment">

<a href="">Tuesday, November 2</a> . . . At 6pm, CCA Curatorial Program 
students will present three brief talks. <br /><br />

<a href="">Thursday, November 4</a> . . . Nairy Baghramanian will lead a 
walking tour of 202 De Haro. It starts at noon.<br /><br />

<a href="">Friday, November 12</a> . . . We are having drinks Next Door. 
Come by! It starts at 9pm.<br /><br />

<a href="">Tuesday, November 16</a> . . . Ryan Gander is in town and will 
be at the Wattis. Stop by for lunch and a casual conversation.<br /><br 
/>

</span>

</div>

<script type="text/javascript">

                message[1] =    [
                                "+++",
                                "-++",
                                "+-+",
                                "++-",
                                ];

                delay[1] = 300;

window.onload=initEmoticons(2, message, delay);
</script>

<?php
require_once("GLOBAL/foot.php");
?>
