<?php
require_once("GLOBAL/head.php");
?>

<div class="imageContainerWrapper dev">
<div id="image0" class="imageContainer dev2" onclick="expandImage('image0','100px', '10px');"
style="padding: 100px;">
<img src="IMAGES/schinwald01.jpg" style="width: 100%">
</div>
</div>

<div class="imageContainerWrapper dev">
<div id="image1" class="imageContainer dev2" onclick="expandImage('image1','100px', '10px');"
style="padding: 100px;">
<img src="IMAGES/schinwald02.jpg" style="width: 100%">
</div>
</div>



<?php
require_once("GLOBAL/foot.php");
?>
