<?php
require_once("GLOBAL/head.php");
?>

<div class="mainContainer times big black">

<span class="listContainer times show comment">
<canvas id="canvas1" width="46" height="22" class="show">% )</canvas>
Consult the Archive. . .<br/><br/></span>

<span class="listContainer times show comment"> 
The complete CCA Wattis Institute exhibition program since 1998 is 
available online.<br/><br/><br/><br/>
</span>

<span class="listContainer times show comment"><span
class="monaco">[*]</span> <a href="">2014–present . . . </a></span>

<span class="listContainer times show comment"><span 
class="monaco">[<]</span> <a 
href="http://wattis.org/exhibitions/archive">1998–2014 (exhibitions) . . 
.</a></span>

<span class="listContainer times show comment"><span 
class="monaco">{<}</span> <a 
href="http://wattis.org/calendar/archive">1998–2014 (events) . . .</a></span>

<script type="text/javascript">
window.onload=initEmoticons(1, message, delay);
</script>

</div>

<script type="text/javascript">

                message[1] =    [
                                ">/?",
                                ">/ "
                                ];

                delay[1] = 500;

window.onload=initEmoticons(2, message, delay);
</script>

<?php
require_once("GLOBAL/foot.php");
?>
