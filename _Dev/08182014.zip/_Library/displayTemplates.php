<?php




  //////////////////
 //  Template 1  //
//////////////////

function displayTemplate1($objects) {


}












?>